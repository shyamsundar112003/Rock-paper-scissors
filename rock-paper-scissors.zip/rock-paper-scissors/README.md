# Rock Paper Scissors

A Pen created on CodePen.io. Original URL: [https://codepen.io/bradtraversy/pen/wLgPzr](https://codepen.io/bradtraversy/pen/wLgPzr).

